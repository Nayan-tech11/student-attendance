# Student Attendance Management System

A Django CRUD application to manage student attendance records.
Built for AAI LAB - CCA1 (Django Project, Basic CRUD Operations).

## Features
- Mark attendance with student name, roll number, class, date, and status
- View all attendance records in a table with color-coded status badges
- Edit existing attendance entries
- Delete attendance records with confirmation
- Django admin panel for backend management

## Tech Stack
- Python 3
- Django 5.x
- SQLite (default Django DB)

## Setup Instructions

1. Clone the repository
   ```
   git clone <your-repo-url>
   cd attendance_project
   ```

2. Create and activate a virtual environment
   ```
   python -m venv venv
   venv\Scripts\activate      # Windows
   source venv/bin/activate   # Mac/Linux
   ```

3. Install dependencies
   ```
   pip install -r requirements.txt
   ```

4. Run migrations
   ```
   python manage.py makemigrations
   python manage.py migrate
   ```

5. Create a superuser (for admin panel access)
   ```
   python manage.py createsuperuser
   ```

6. Run the development server
   ```
   python manage.py runserver
   ```

7. Open in browser
   - App: http://127.0.0.1:8000/
   - Attendance list: http://127.0.0.1:8000/attendance/
   - Admin: http://127.0.0.1:8000/admin/

## Project Structure
```
attendance_project/
├── manage.py
├── requirements.txt
├── attendance_project/     # project settings
└── attendance/             # CRUD app
    ├── models.py           # Attendance model
    ├── views.py            # CRUD views
    ├── forms.py            # ModelForm
    ├── urls.py
    ├── admin.py
    └── templates/attendance/   # home, list, form, delete templates
```

## Screenshots
See attached PDF for screenshots of the home, list, add, and edit views.
