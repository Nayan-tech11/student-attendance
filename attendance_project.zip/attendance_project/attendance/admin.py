from django.contrib import admin
from .models import Attendance


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('student_name', 'roll_number', 'student_class', 'date', 'status')
    list_filter = ('status', 'student_class', 'date')
    search_fields = ('student_name', 'roll_number')
