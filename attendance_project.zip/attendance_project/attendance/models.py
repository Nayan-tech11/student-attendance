from django.db import models


class Attendance(models.Model):
    STATUS_CHOICES = [
        ('Present', 'Present'),
        ('Absent', 'Absent'),
        ('Leave', 'Leave'),
    ]

    student_name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=10)
    student_class = models.CharField(max_length=20, verbose_name="Class")
    date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Present')

    def __str__(self):
        return f"{self.student_name} ({self.roll_number}) - {self.date}"

    class Meta:
        ordering = ['-date', 'roll_number']
