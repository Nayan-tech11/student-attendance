from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('attendance/', views.attendance_list, name='attendance_list'),
    path('attendance/add/', views.attendance_add, name='attendance_add'),
    path('attendance/edit/<int:pk>/', views.attendance_edit, name='attendance_edit'),
    path('attendance/delete/<int:pk>/', views.attendance_delete, name='attendance_delete'),
]
